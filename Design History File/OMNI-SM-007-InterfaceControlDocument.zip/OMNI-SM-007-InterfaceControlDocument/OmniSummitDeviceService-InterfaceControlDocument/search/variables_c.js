var searchData=
[
  ['query_459',['query',['../struct_query_bridges_request.html#a3bee70fd555f25651c0c88ec3e956e47',1,'QueryBridgesRequest::query()'],['../struct_list_device_request.html#a6b931bb660d37d492dfb5e95bc081acb',1,'ListDeviceRequest::query()']]]
];
