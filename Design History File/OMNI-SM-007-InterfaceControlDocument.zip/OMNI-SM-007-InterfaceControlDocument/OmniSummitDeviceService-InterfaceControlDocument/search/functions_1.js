var searchData=
[
  ['bandpowerstream_325',['BandPowerStream',['../class_open_mind_server_1_1_services_1_1_device_manager_service.html#a3b76e936182dfc14c4f541e715afe71f',1,'OpenMindServer::Services::DeviceManagerService']]],
  ['bridgemanagerservice_326',['BridgeManagerService',['../class_open_mind_server_1_1_services_1_1_bridge_manager_service.html#ab4e62a3585bd1f81ce7dd2e0ea45eaa5',1,'OpenMindServer::Services::BridgeManagerService']]]
];
