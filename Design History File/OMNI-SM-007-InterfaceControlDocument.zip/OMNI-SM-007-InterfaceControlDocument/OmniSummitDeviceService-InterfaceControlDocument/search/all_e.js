var searchData=
[
  ['query_175',['query',['../struct_query_bridges_request.html#a3bee70fd555f25651c0c88ec3e956e47',1,'QueryBridgesRequest::query()'],['../struct_list_device_request.html#a6b931bb660d37d492dfb5e95bc081acb',1,'ListDeviceRequest::query()']]],
  ['querybridgesrequest_176',['QueryBridgesRequest',['../struct_query_bridges_request.html',1,'']]],
  ['querybridgesresponse_177',['QueryBridgesResponse',['../struct_query_bridges_response.html',1,'']]]
];
