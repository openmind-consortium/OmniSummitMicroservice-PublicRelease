var searchData=
[
  ['adaptivedataqueue_483',['AdaptiveDataQueue',['../class_open_mind_server_1_1_summit_service_info.html#a108857b9c0134f8ff079ebefe73dc2a3',1,'OpenMindServer::SummitServiceInfo']]],
  ['address_484',['Address',['../class_open_mind_server_1_1_summit_service_info.html#aae9b79d8aad24bb4ea8813dcd0d138eb',1,'OpenMindServer::SummitServiceInfo']]]
];
