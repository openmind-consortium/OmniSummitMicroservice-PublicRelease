var searchData=
[
  ['name_493',['Name',['../class_open_mind_server_1_1_summit_service_info.html#a5967d78a39dd309e1ecc6fd11c9284cd',1,'OpenMindServer::SummitServiceInfo']]]
];
