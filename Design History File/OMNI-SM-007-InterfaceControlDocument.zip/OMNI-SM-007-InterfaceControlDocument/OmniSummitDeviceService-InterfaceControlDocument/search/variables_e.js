var searchData=
[
  ['sample_5frate_464',['sample_rate',['../struct_summit_accelerometer_stream_configuration.html#a65c97d8b6ba1f004e205bb459938b951',1,'SummitAccelerometerStreamConfiguration']]],
  ['sense_5fenables_5fconfig_465',['sense_enables_config',['../struct_sense_configuration_request.html#aec3962527102ebee3878e37c39e85b34',1,'SenseConfigurationRequest']]],
  ['serial_5fnumber_466',['serial_number',['../struct_describe_bridge_response.html#aecf4c557c66dbf288007ead9126242f6',1,'DescribeBridgeResponse']]],
  ['size_467',['size',['../struct_summit_fast_fourier_transform_stream_configuration.html#a39d893f5363a76185e34289b31588172',1,'SummitFastFourierTransformStreamConfiguration']]],
  ['soc_5funcertainty_468',['soc_uncertainty',['../struct_device_status_response.html#a3e894cadd10800ef9162e249bccdc904',1,'DeviceStatusResponse']]],
  ['stimulation_5fpulse_5findeces_469',['stimulation_pulse_indeces',['../struct_time_domain_channel_data.html#af0866b1bc57512f808a9aedd72fb17db',1,'TimeDomainChannelData']]],
  ['stream_5fconfigure_5fstatus_470',['stream_configure_status',['../struct_stream_configure_response.html#a3ee90e6449af0747007613f904482c97',1,'StreamConfigureResponse']]],
  ['streaming_5frate_471',['streaming_rate',['../struct_miscellaneous_stream_configuration.html#afe109aac3f30023ae70bd8c417c14869',1,'MiscellaneousStreamConfiguration']]],
  ['supported_5fdevices_472',['supported_devices',['../struct_supported_devices_response.html#ab40f5a351794f67e237a8005580627c0',1,'SupportedDevicesResponse']]]
];
