var searchData=
[
  ['inertialdataqueue_490',['InertialDataQueue',['../class_open_mind_server_1_1_summit_service_info.html#a9173c52d1f378b5225a52c920802e175',1,'OpenMindServer::SummitServiceInfo']]],
  ['isdisposed_491',['IsDisposed',['../class_open_mind_server_1_1_summit_service_info.html#a12142d86f0b730b145dcfd1ee0a7715f',1,'OpenMindServer::SummitServiceInfo']]]
];
