var searchData=
[
  ['querybridgesrequest_290',['QueryBridgesRequest',['../struct_query_bridges_request.html',1,'']]],
  ['querybridgesresponse_291',['QueryBridgesResponse',['../struct_query_bridges_response.html',1,'']]]
];
