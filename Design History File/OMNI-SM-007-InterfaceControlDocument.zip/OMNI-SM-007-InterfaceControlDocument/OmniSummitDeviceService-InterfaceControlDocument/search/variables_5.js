var searchData=
[
  ['fft_5fconfig_431',['fft_config',['../struct_sense_configuration_request.html#acbf722b4155b3f136ba8463e0bb2c14f',1,'SenseConfigurationRequest']]],
  ['fft_5fstream_5fchannel_432',['fft_stream_channel',['../struct_summit_sense_enables_configuration.html#a65fac31a1f7edd55ae725b1364339e91',1,'SummitSenseEnablesConfiguration']]],
  ['firmware_5fversion_433',['firmware_version',['../struct_describe_bridge_response.html#a4c1d212117402dd9d14222c8e4cb7660',1,'DescribeBridgeResponse']]],
  ['full_5fsoc_434',['full_soc',['../struct_device_status_response.html#a1ad9b97662615e05d7a4723e51334d47',1,'DeviceStatusResponse']]]
];
