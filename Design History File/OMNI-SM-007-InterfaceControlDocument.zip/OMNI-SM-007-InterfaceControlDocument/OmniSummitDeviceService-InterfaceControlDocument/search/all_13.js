var searchData=
[
  ['version_5fnumber_239',['version_number',['../struct_version_number_response.html#ad7f4c2f001cc21ebad834eb8320bee51',1,'VersionNumberResponse']]],
  ['versionnumber_240',['VersionNumber',['../class_open_mind_server_1_1_services_1_1_info_service.html#a05019d0a87ffc08ad998cf92636ef85c',1,'OpenMindServer::Services::InfoService']]],
  ['versionnumberrequest_241',['VersionNumberRequest',['../struct_version_number_request.html',1,'']]],
  ['versionnumberresponse_242',['VersionNumberResponse',['../struct_version_number_response.html',1,'']]]
];
