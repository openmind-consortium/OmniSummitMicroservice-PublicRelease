var searchData=
[
  ['connection_5fstatus_407',['connection_status',['../struct_connect_bridge_response.html#a6213b1bdbf60c26e1814525711adcc6b',1,'ConnectBridgeResponse::connection_status()'],['../struct_connection_update.html#a41ee6db8b07f3531d8672b1bd5de4484',1,'ConnectionUpdate::connection_status()'],['../struct_connect_device_response.html#a503a9c2cf6499027d9f95d2d206dc248',1,'ConnectDeviceResponse::connection_status()']]]
];
