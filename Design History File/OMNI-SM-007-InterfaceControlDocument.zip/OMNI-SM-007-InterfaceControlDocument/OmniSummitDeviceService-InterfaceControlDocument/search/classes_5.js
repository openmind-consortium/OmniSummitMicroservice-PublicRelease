var searchData=
[
  ['fouriertransformchanneldata_269',['FourierTransformChannelData',['../struct_fourier_transform_channel_data.html',1,'']]],
  ['fouriertransformupdate_270',['FourierTransformUpdate',['../struct_fourier_transform_update.html',1,'']]]
];
