var searchData=
[
  ['port_494',['Port',['../class_open_mind_server_1_1_omni_server.html#a8197fa257f4f9ef26c222d01eb06893b',1,'OpenMindServer::OmniServer']]]
];
