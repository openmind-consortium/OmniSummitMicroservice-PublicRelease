var searchData=
[
  ['accelerometer_5fconfig_391',['accelerometer_config',['../struct_sense_configuration_request.html#a4e51a900fc4ef156efdadd95a2fb683d',1,'SenseConfigurationRequest']]]
];
