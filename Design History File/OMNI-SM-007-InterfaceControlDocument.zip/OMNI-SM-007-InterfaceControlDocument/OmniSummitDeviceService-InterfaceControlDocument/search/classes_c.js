var searchData=
[
  ['repository_292',['Repository',['../class_open_mind_server_1_1_repository.html',1,'OpenMindServer']]]
];
