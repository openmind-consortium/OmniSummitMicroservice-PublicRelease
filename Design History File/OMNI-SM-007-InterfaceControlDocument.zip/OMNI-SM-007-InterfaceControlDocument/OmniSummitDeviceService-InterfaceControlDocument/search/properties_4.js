var searchData=
[
  ['fourierdataqueue_488',['FourierDataQueue',['../class_open_mind_server_1_1_summit_service_info.html#a2225ef4ced1f38ff2d517a1eb750471a',1,'OpenMindServer::SummitServiceInfo']]]
];
