var searchData=
[
  ['getaddresses_109',['GetAddresses',['../class_open_mind_server_1_1_repository.html#a6deba3d088df051fb5b9291524f8bf3d',1,'OpenMindServer::Repository']]],
  ['getbridgeaddressbyname_110',['GetBridgeAddressByName',['../class_open_mind_server_1_1_repository.html#ae019ba1470c99cad4b1fa8e2d1dc64a7',1,'OpenMindServer::Repository']]],
  ['getconnectionbyname_111',['GetConnectionByName',['../class_open_mind_server_1_1_repository.html#af0eaf2e3fff7fa595aeff31a055c2168',1,'OpenMindServer::Repository']]],
  ['getdeviceaddressbyname_112',['GetDeviceAddressByName',['../class_open_mind_server_1_1_repository.html#a49600a97b6bdca1f6b3a14fcd457e0c6',1,'OpenMindServer::Repository']]],
  ['getdeviceserial_113',['GetDeviceSerial',['../class_open_mind_server_1_1_summit_service_info.html#ae3dc8cb8d7091ea0f11993d74550ca88',1,'OpenMindServer::SummitServiceInfo']]],
  ['getrepositoryinstance_114',['GetRepositoryInstance',['../class_open_mind_server_1_1_repository.html#a50d7da0b09b6ae4c754908aa8e491795',1,'OpenMindServer::Repository']]]
];
