var searchData=
[
  ['describebridge_347',['DescribeBridge',['../class_open_mind_server_1_1_services_1_1_bridge_manager_service.html#a9f94e02f2e1e46e198e2b9c1b8f0d8f2',1,'OpenMindServer.Services.BridgeManagerService.DescribeBridge()'],['../class_open_mind_server_1_1_summit_service.html#a1e3fec8136edf72fc1d47d8b3cb64575',1,'OpenMindServer.SummitService.DescribeBridge()']]],
  ['devicemanagerservice_348',['DeviceManagerService',['../class_open_mind_server_1_1_services_1_1_device_manager_service.html#a3ec2e6792a96a2b7eba393b48ea2ee8d',1,'OpenMindServer::Services::DeviceManagerService']]],
  ['devicestatus_349',['DeviceStatus',['../class_open_mind_server_1_1_services_1_1_device_manager_service.html#a0d9579ce884c6f45d6474bf33ba838b6',1,'OpenMindServer.Services.DeviceManagerService.DeviceStatus()'],['../class_open_mind_server_1_1_summit_service.html#abd2c587e8d3519767ca4211508e33da1',1,'OpenMindServer.SummitService.DeviceStatus()']]],
  ['disablestream_350',['DisableStream',['../class_open_mind_server_1_1_summit_service.html#a4ecc1a29c81cc048d13688050c2670e8',1,'OpenMindServer::SummitService']]],
  ['disconnectbridge_351',['DisconnectBridge',['../class_open_mind_server_1_1_services_1_1_bridge_manager_service.html#a46c4aa5e6b4f01a7f2f870c16b5d809c',1,'OpenMindServer::Services::BridgeManagerService']]],
  ['disconnectdevice_352',['DisconnectDevice',['../class_open_mind_server_1_1_services_1_1_device_manager_service.html#a03eff43526a1a4547bd0e2bb49d3a25e',1,'OpenMindServer::Services::DeviceManagerService']]],
  ['disconnectfrombridge_353',['DisconnectFromBridge',['../class_open_mind_server_1_1_summit_service.html#adaf56900a9391b1870252af9b060dcff',1,'OpenMindServer::SummitService']]],
  ['disconnectfromdevice_354',['DisconnectFromDevice',['../class_open_mind_server_1_1_summit_service.html#a22589c8faaf4e678194a97936e1f86ea',1,'OpenMindServer::SummitService']]],
  ['dispose_355',['Dispose',['../class_open_mind_server_1_1_summit_service_info.html#a0c9a6cfe579b3ebfb26dd9c6c8104311',1,'OpenMindServer.SummitServiceInfo.Dispose()'],['../class_open_mind_server_1_1_summit_service_info.html#a2f150b566e48b003d19383e03a86fef9',1,'OpenMindServer.SummitServiceInfo.Dispose(bool disposing)']]]
];
