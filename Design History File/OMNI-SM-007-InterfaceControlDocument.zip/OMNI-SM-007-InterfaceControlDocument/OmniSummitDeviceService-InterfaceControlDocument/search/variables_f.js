var searchData=
[
  ['td_5fchannel_5fconfigs_473',['td_channel_configs',['../struct_sense_configuration_request.html#ae5e4ef2c643a15d3b1d74ca5b0ebfd02',1,'SenseConfigurationRequest']]],
  ['telemetry_5fmode_474',['telemetry_mode',['../struct_connect_bridge_request.html#a252509648153066be9667a188bfed4e4',1,'ConnectBridgeRequest::telemetry_mode()'],['../struct_describe_bridge_response.html#a1d78cf26f84fb3863cb4e37e69c684cd',1,'DescribeBridgeResponse::telemetry_mode()']]],
  ['telemetry_5fratio_475',['telemetry_ratio',['../struct_connect_bridge_request.html#aceb0181e29523fa6d47e30ee3b0a9ad2',1,'ConnectBridgeRequest::telemetry_ratio()'],['../struct_describe_bridge_response.html#af2d451ced733128cf3b618b4cda1df73',1,'DescribeBridgeResponse::telemetry_ratio()']]],
  ['therapy_5funavailable_5fsoc_476',['therapy_unavailable_soc',['../struct_device_status_response.html#ae0e7a7d67b9c75881c4b44e1f64837b1',1,'DeviceStatusResponse']]],
  ['timedomain_5fsampling_5frate_477',['timedomain_sampling_rate',['../struct_sense_configuration_request.html#a7c233b2965dc29d9d5b7d1a59485abef',1,'SenseConfigurationRequest']]],
  ['transmit_5fattempts_478',['transmit_attempts',['../struct_summit_error.html#a6e24bf57b69baf1e22480c6293d6aee6',1,'SummitError']]],
  ['tx_5ftime_479',['tx_time',['../struct_summit_error.html#adad5e3ebdec2deb10efaba307254c2da',1,'SummitError']]]
];
