var searchData=
[
  ['versionnumber_390',['VersionNumber',['../class_open_mind_server_1_1_services_1_1_info_service.html#a05019d0a87ffc08ad998cf92636ef85c',1,'OpenMindServer::Services::InfoService']]]
];
