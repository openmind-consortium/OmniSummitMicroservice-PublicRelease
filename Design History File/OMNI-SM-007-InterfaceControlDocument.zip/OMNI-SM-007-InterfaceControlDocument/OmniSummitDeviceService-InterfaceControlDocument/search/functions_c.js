var searchData=
[
  ['senseconfiguration_379',['SenseConfiguration',['../class_open_mind_server_1_1_services_1_1_device_manager_service.html#a16c3c955c7fdc02a693180fff6b8874b',1,'OpenMindServer::Services::DeviceManagerService']]],
  ['setdeviceserial_380',['SetDeviceSerial',['../class_open_mind_server_1_1_summit_service_info.html#ac7bdb7f9f4a307873e03030bd7d5cbbe',1,'OpenMindServer::SummitServiceInfo']]],
  ['shutdown_381',['Shutdown',['../class_open_mind_server_1_1_summit_service.html#a2cb90cb5080fb3db6c3a3dd66ba4a725',1,'OpenMindServer::SummitService']]],
  ['startserver_382',['StartServer',['../class_open_mind_server_1_1_omni_server.html#a1fafd13a453770524e71f276c00a7529',1,'OpenMindServer::OmniServer']]],
  ['stopserver_383',['StopServer',['../class_open_mind_server_1_1_omni_server.html#a91bdfb48b9ffd8b95f4931b444d72aca',1,'OpenMindServer::OmniServer']]],
  ['streamdisable_384',['StreamDisable',['../class_open_mind_server_1_1_services_1_1_device_manager_service.html#a964c25109aa24e31bca28c115c213faa',1,'OpenMindServer::Services::DeviceManagerService']]],
  ['streamenable_385',['StreamEnable',['../class_open_mind_server_1_1_services_1_1_device_manager_service.html#afe38d98eaded0cc792e2e28046cca606',1,'OpenMindServer::Services::DeviceManagerService']]],
  ['summitservice_386',['SummitService',['../class_open_mind_server_1_1_summit_service.html#a7d8615bcf0637363be6fe7a543e8ae8a',1,'OpenMindServer::SummitService']]],
  ['summitserviceinfo_387',['SummitServiceInfo',['../class_open_mind_server_1_1_summit_service_info.html#aa3822349560d0088fd058ad2a000ebd7',1,'OpenMindServer::SummitServiceInfo']]],
  ['supporteddevices_388',['SupportedDevices',['../class_open_mind_server_1_1_services_1_1_info_service.html#a0392b9cff6cd1bcf97e25d73525945ee',1,'OpenMindServer::Services::InfoService']]]
];
