var searchData=
[
  ['main_372',['Main',['../class_open_mind_server_1_1_server.html#a6bcb890f606c31ea7d52f483685ab472',1,'OpenMindServer::Server']]]
];
