var searchData=
[
  ['summit_495',['Summit',['../class_open_mind_server_1_1_summit_service_info.html#a0445e75e1f71141f0fa8e40157f2cb9b',1,'OpenMindServer::SummitServiceInfo']]],
  ['summitsystem_496',['SummitSystem',['../class_open_mind_server_1_1_wrappers_1_1_omni_system.html#ab28703322df1742227ec41e12fdd1814',1,'OpenMindServer::Wrappers::OmniSystem']]],
  ['supporteddevices_497',['SupportedDevices',['../class_open_mind_server_1_1_omni_server.html#add70fba5eedf133f13f6427e657f2b8e',1,'OpenMindServer::OmniServer']]]
];
