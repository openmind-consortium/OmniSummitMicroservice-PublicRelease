var searchData=
[
  ['detector_5fnumber_408',['detector_number',['../struct_summit_linear_detector_configuration.html#aa8ceac5edfc01d6d90db877d15b133f6',1,'SummitLinearDetectorConfiguration']]],
  ['device_5fcommand_5fcode_409',['device_command_code',['../struct_summit_error.html#a74ac501aac37c8abcbd86a85e64ec6d8',1,'SummitError']]],
  ['devices_410',['devices',['../struct_list_device_response.html#a99d76ffecdb37fe47709cc4fa97c5406',1,'ListDeviceResponse']]],
  ['disabled_411',['disabled',['../struct_summit_time_domain_channel_config.html#ae9d0b3765f82111382c999342b838a9d',1,'SummitTimeDomainChannelConfig']]]
];
