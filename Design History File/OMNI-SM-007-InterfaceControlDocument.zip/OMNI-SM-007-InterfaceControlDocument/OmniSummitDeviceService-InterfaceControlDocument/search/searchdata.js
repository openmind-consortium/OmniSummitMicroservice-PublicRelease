var indexSectionsWithContent =
{
  0: "abcdefghilmnopqrstuvw",
  1: "abcdefilmopqrstv",
  2: "o",
  3: "abcdefgilmorstv",
  4: "abcdefhilmnpqrstvw",
  5: "abcefhilnpst",
  6: "u"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "variables",
  5: "properties",
  6: "events"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Variables",
  5: "Properties",
  6: "Events"
};

