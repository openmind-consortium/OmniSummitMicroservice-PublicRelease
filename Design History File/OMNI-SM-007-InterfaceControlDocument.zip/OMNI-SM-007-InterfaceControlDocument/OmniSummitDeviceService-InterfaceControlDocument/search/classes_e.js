var searchData=
[
  ['timedomainchanneldata_314',['TimeDomainChannelData',['../struct_time_domain_channel_data.html',1,'']]],
  ['timedomainchannelstimtiming_315',['TimeDomainChannelStimTiming',['../struct_time_domain_channel_stim_timing.html',1,'']]],
  ['timedomainupdate_316',['TimeDomainUpdate',['../struct_time_domain_update.html',1,'']]]
];
