var searchData=
[
  ['td_5fchannel_5fconfigs_226',['td_channel_configs',['../struct_sense_configuration_request.html#ae5e4ef2c643a15d3b1d74ca5b0ebfd02',1,'SenseConfigurationRequest']]],
  ['telemetry_5fmode_227',['telemetry_mode',['../struct_connect_bridge_request.html#a252509648153066be9667a188bfed4e4',1,'ConnectBridgeRequest::telemetry_mode()'],['../struct_describe_bridge_response.html#a1d78cf26f84fb3863cb4e37e69c684cd',1,'DescribeBridgeResponse::telemetry_mode()']]],
  ['telemetry_5fratio_228',['telemetry_ratio',['../struct_connect_bridge_request.html#aceb0181e29523fa6d47e30ee3b0a9ad2',1,'ConnectBridgeRequest::telemetry_ratio()'],['../struct_describe_bridge_response.html#af2d451ced733128cf3b618b4cda1df73',1,'DescribeBridgeResponse::telemetry_ratio()']]],
  ['therapy_5funavailable_5fsoc_229',['therapy_unavailable_soc',['../struct_device_status_response.html#ae0e7a7d67b9c75881c4b44e1f64837b1',1,'DeviceStatusResponse']]],
  ['timedomain_5fsampling_5frate_230',['timedomain_sampling_rate',['../struct_sense_configuration_request.html#a7c233b2965dc29d9d5b7d1a59485abef',1,'SenseConfigurationRequest']]],
  ['timedomainchanneldata_231',['TimeDomainChannelData',['../struct_time_domain_channel_data.html',1,'']]],
  ['timedomainchannelstimtiming_232',['TimeDomainChannelStimTiming',['../struct_time_domain_channel_stim_timing.html',1,'']]],
  ['timedomaindataqueue_233',['TimeDomainDataQueue',['../class_open_mind_server_1_1_summit_service_info.html#ac94502d12643b985f4dbce7117c00452',1,'OpenMindServer::SummitServiceInfo']]],
  ['timedomainstream_234',['TimeDomainStream',['../class_open_mind_server_1_1_services_1_1_device_manager_service.html#ae212ea3547970bcc1f7409cd2884029b',1,'OpenMindServer::Services::DeviceManagerService']]],
  ['timedomainupdate_235',['TimeDomainUpdate',['../struct_time_domain_update.html',1,'']]],
  ['transmit_5fattempts_236',['transmit_attempts',['../struct_summit_error.html#a6e24bf57b69baf1e22480c6293d6aee6',1,'SummitError']]],
  ['tx_5ftime_237',['tx_time',['../struct_summit_error.html#adad5e3ebdec2deb10efaba307254c2da',1,'SummitError']]]
];
