var searchData=
[
  ['bandpowerchanneldata_246',['BandPowerChannelData',['../struct_band_power_channel_data.html',1,'']]],
  ['bandpowerupdate_247',['BandPowerUpdate',['../struct_band_power_update.html',1,'']]],
  ['bridge_248',['Bridge',['../struct_bridge.html',1,'']]],
  ['bridgemanagerservice_249',['BridgeManagerService',['../class_open_mind_server_1_1_services_1_1_bridge_manager_service.html',1,'OpenMindServer::Services']]]
];
