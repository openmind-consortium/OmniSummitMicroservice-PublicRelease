var searchData=
[
  ['removebridgeaddressbyname_376',['RemoveBridgeAddressByName',['../class_open_mind_server_1_1_repository.html#aac5fbcf0bc91c0a419dd6b16359f45eb',1,'OpenMindServer::Repository']]],
  ['removeconnectionbyname_377',['RemoveConnectionByName',['../class_open_mind_server_1_1_repository.html#a0bc01181795089e5397fae913e354a54',1,'OpenMindServer::Repository']]],
  ['removedeviceaddressbyname_378',['RemoveDeviceAddressByName',['../class_open_mind_server_1_1_repository.html#ae7250ce3dc1e6bd02864f4dfb23de144',1,'OpenMindServer::Repository']]]
];
