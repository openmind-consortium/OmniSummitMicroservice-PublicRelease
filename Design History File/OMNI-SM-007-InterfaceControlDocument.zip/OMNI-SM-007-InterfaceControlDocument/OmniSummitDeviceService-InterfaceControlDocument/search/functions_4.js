var searchData=
[
  ['echostream_356',['EchoStream',['../class_open_mind_server_1_1_services_1_1_device_manager_service.html#af6714037220e87af0f6a3543df27abc6',1,'OpenMindServer::Services::DeviceManagerService']]],
  ['enablestream_357',['EnableStream',['../class_open_mind_server_1_1_summit_service.html#a7f9317dc7ea890dea98079f94d416408',1,'OpenMindServer::SummitService']]]
];
