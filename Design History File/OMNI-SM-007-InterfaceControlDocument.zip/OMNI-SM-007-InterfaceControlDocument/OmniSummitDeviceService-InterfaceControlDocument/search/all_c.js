var searchData=
[
  ['omnimanager_159',['OmniManager',['../class_open_mind_server_1_1_wrappers_1_1_omni_manager.html',1,'OpenMindServer.Wrappers.OmniManager'],['../class_open_mind_server_1_1_wrappers_1_1_omni_manager.html#a62bc4ecf97a8158059fa4bf302f76195',1,'OpenMindServer.Wrappers.OmniManager.OmniManager()']]],
  ['omniserver_160',['OmniServer',['../class_open_mind_server_1_1_omni_server.html',1,'OpenMindServer.OmniServer'],['../class_open_mind_server_1_1_omni_server.html#a4a74fd92b5ee48e5173abcb5735cdf49',1,'OpenMindServer.OmniServer.OmniServer()']]],
  ['omnisummitdeviceservice_161',['OmniSummitDeviceService',['../namespace_omni_summit_device_service.html',1,'']]],
  ['omnisystem_162',['OmniSystem',['../class_open_mind_server_1_1_wrappers_1_1_omni_system.html',1,'OpenMindServer.Wrappers.OmniSystem'],['../class_open_mind_server_1_1_wrappers_1_1_omni_system.html#adaa44ea78c8cd27fc7b86835293855e9',1,'OpenMindServer.Wrappers.OmniSystem.OmniSystem()']]],
  ['openmindserver_163',['OpenMindServer',['../namespace_open_mind_server.html',1,'']]],
  ['services_164',['Services',['../namespace_open_mind_server_1_1_services.html',1,'OpenMindServer']]],
  ['unittests_165',['UnitTests',['../namespace_omni_summit_device_service_1_1_unit_tests.html',1,'OmniSummitDeviceService.UnitTests'],['../namespace_open_mind_server_1_1_unit_tests.html',1,'OpenMindServer.UnitTests']]],
  ['wrappers_166',['Wrappers',['../namespace_open_mind_server_1_1_wrappers.html',1,'OpenMindServer']]]
];
