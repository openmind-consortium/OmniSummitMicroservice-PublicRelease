var searchData=
[
  ['connectionstatusqueue_486',['ConnectionStatusQueue',['../class_open_mind_server_1_1_summit_service_info.html#a5f0544383e4ae405f174937ddaca1125',1,'OpenMindServer::SummitServiceInfo']]]
];
