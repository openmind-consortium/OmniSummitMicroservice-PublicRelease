var searchData=
[
  ['omnimanager_286',['OmniManager',['../class_open_mind_server_1_1_wrappers_1_1_omni_manager.html',1,'OpenMindServer::Wrappers']]],
  ['omniserver_287',['OmniServer',['../class_open_mind_server_1_1_omni_server.html',1,'OpenMindServer']]],
  ['omnisystem_288',['OmniSystem',['../class_open_mind_server_1_1_wrappers_1_1_omni_system.html',1,'OpenMindServer::Wrappers']]]
];
