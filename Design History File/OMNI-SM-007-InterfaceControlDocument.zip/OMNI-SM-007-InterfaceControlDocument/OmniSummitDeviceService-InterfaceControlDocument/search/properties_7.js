var searchData=
[
  ['looprecordqueue_492',['LoopRecordQueue',['../class_open_mind_server_1_1_summit_service_info.html#a6180c3550faa01b88f5e8fd334c23fad',1,'OpenMindServer::SummitServiceInfo']]]
];
