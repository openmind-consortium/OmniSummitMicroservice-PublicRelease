var searchData=
[
  ['omnimanager_373',['OmniManager',['../class_open_mind_server_1_1_wrappers_1_1_omni_manager.html#a62bc4ecf97a8158059fa4bf302f76195',1,'OpenMindServer::Wrappers::OmniManager']]],
  ['omniserver_374',['OmniServer',['../class_open_mind_server_1_1_omni_server.html#a4a74fd92b5ee48e5173abcb5735cdf49',1,'OpenMindServer::OmniServer']]],
  ['omnisystem_375',['OmniSystem',['../class_open_mind_server_1_1_wrappers_1_1_omni_system.html#adaa44ea78c8cd27fc7b86835293855e9',1,'OpenMindServer::Wrappers::OmniSystem']]]
];
